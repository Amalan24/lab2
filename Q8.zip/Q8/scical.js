    let outputBox = document.getElementById("output");
    function display(num){
        if(outputBox.value != 'INVALID'){
            outputBox.value+= num;
        }
    }

    function equals(){
        try{
            outputBox.value = eval(outputBox.value);
        }
        catch(err){
            outputBox.value="Invalid";
        }
    }

    function clearOutput(){
        outputBox.value = "";
    }

    function backSpace(){
        outputBox.value=outputBox.value.slice(0,-1);
    }

    function fact(){
        let a = outputBox.value;
        let fact = 1;
        outputBox.value += '!';
        document.getElementById("calculate").onclick = function(){
            for(let i=1;i<=a;i++){
                fact*=i; 
            }
            outputBox.value = fact;
        }
    }

    function sin(){
        let a = outputBox.value;
        let res = Math.sin(a*Math.PI/180);
        outputBox.value = res;
    }

    function cos(){
        let a = outputBox.value;
        let res = Math.cos(a*Math.PI/180);
        outputBox.value = res;
    }

    function tan(){
        let a = outputBox.value;
        let res = Math.tan(a*Math.PI/180);
        outputBox.value = res;
    }

    function abs(){
        let a = outputBox.value;
        let res = Math.abs(a);
        outputBox.value = res;
    }

    function round(){
        let a= outputBox.value;
        let res = Math.round(a);
        outputBox.value = res;
    }

    function inverse(){
        let a = outputBox.value;
        let res = 1/a;
        outputBox.value = res;
    }

    function log(){
        let a= outputBox.value;
        let res = Math.log(a);
        outputBox.value = res;
    }

    function log10(){
        let a= outputBox.value;
        let res = Math.log10(a);
        outputBox.value = res;
    }