let outputScreen = document.getElementById('bill');
function calculate(){
    let a = Number(outputScreen.value);
    let res = 0;
    document.getElementById('consumed-units').innerHTML = outputScreen.value;
    if(a<=150){
        document.getElementById("total-current-charges1").innerHTML= 0.0;
        document.getElementById("total-current-charges2").innerHTML= 0.0;
    }
    if(a>150 && a<=350){
        res = 100 + a*3.75;
        document.getElementById("total-current-charges1").innerHTML= res;
        document.getElementById("total-current-charges2").innerHTML= res;
    }
    if(a>350 && a<=450){
        let b = a-350;
       res = (100+200*3.75)+(b*4+250);
       document.getElementById("total-current-charges1").innerHTML= res;
       document.getElementById("total-current-charges2").innerHTML= res;
   }
   if(a>450 && a<=600){
       let b = a - 450;
       res = (100+200*3.75)+(250+100*4)+(300+b*4.25);
       document.getElementById("total-current-charges1").innerHTML = res;
       document.getElementById("total-current-charges2").innerHTML = res;
   }
   if(a>600){
    let b = a - 600;
    res = (100+200*3.75)+(250+100*4)+(300+150*4.25)+(400+b*5);
    document.getElementById("total-current-charges1").innerHTML = res;
    document.getElementById("total-current-charges2").innerHTML = res;
   }

   let bill = res+50-250;
   console.log(bill);
   document.getElementById("net-amount").innerHTML = bill;   
}

