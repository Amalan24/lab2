let colorIndex = 0;
const color = ['color1.png','color2.png','color3.png','color4.png','color5.png'];
function swapColor(){
    const box = document.getElementById('colorSwap');
    colorIndex = (colorIndex+1)%color.length;
    box.style.backgroundImage = `url('${color[colorIndex]}')`;
}