var toppings = 0;
var hdelivery = 0;
var dFry = 0;
var calculate = 0;
let smallPizza;
let mediumPizza;
let largePizza;

let sc = document.getElementById("small_count");
let mc = document.getElementById("medium_count");
let lc = document.getElementById("large_count");

let s = document.getElementById("small");
let m = document.getElementById("medium");
let l = document.getElementById("large");

let mushRoom = document.getElementById("mushroom");
let olive = document.getElementById("olives");
let finNail = document.getElementById("fingernail");
let beef = document.getElementById("spicy-beef");

let deepFry = document.getElementById("deepfry");
let deliv = document.getElementById("homedelivery");

let pizzaList = document.getElementById("pizzaList");
let listTop = document.getElementById("listToppings");
let fry = document.getElementById("extraFry");
let home = document.getElementById("deliveryHome");
let finalBill = document.getElementById("finalAmount");

function pizzasmall(){
    if(s.checked){sc.value=1;}
    else{sc.value=0;}
}

function pizzamedium(){
    if(m.checked){mc.value=1;}
    else{mc.value=0;}
}

function pizzalarge(){
    if(l.checked){lc.value=1;}
    else{lc.value=0;}
}

function mush(){
    if(mushRoom.checked){toppings+=15;}
    else{toppings-=15;}
    console.log(toppings);
}

function olives(){
    if(olive.checked){toppings+=10;}
    else{toppings-=10;}
    console.log(toppings);

}

function finger(){
    if(finNail.checked){toppings+=30;}
    else{toppings-=30;}
    console.log(toppings);
}

function spicy(){
    if(beef.checked){toppings+=20;}
    else{toppings-=20;}
    console.log(toppings);

}

function deep(){
    if(deepFry.checked){dFry=20;}
    else{dFry=0;}
    console.log(dFry)
}

function delivery(){
    if(deliv.checked){hdelivery=25;}
    else{hdelivery=0;}
    console.log(hdelivery)
}

function reset(){
    window.location.reload();
}

function placeOrder(){
    pizzaList.innerHTML = "";
    if(s.checked && sc.value!=0){
        smallPizza = sc.value*99;
        pizzaList.innerHTML += "Small pizza ("+sc.value+" nos) => ₹ "+smallPizza+"<br><br>";
    }

    if(m.checked && mc.value!=0){
        mediumPizza = mc.value*199;
        pizzaList.innerHTML += "Medium pizza ("+mc.value+" nos) => ₹ "+mediumPizza+"<br><br>";
    }
    
    if(l.checked && lc.value!=0){
        largePizza = lc.value*399;
        pizzaList.innerHTML += "Large pizza ("+lc.value+" nos) => ₹ "+largePizza+"<br><br>";
    }

    if(toppings!=0){
        listTop.innerHTML = "Extra Toppings => ₹ "+toppings;
    }

    if(dFry!=0){
        fry.innerHTML = "DeepFry added => ₹ "+dFry;
    }

    if(hdelivery!=0){
        home.innerHTML = "Home Delivery => ₹ "+hdelivery;
    }
    calculate = (sc.value*99) + (mc.value*199) + (lc.value*399) + toppings + hdelivery + dFry;
    console.log(calculate);
    if(calculate!=0){
        finalBill.innerHTML = "Total amount : ₹ "+calculate;
    }
}

