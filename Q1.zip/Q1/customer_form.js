/*let display = document.getElementById('second-output');
let generateButton = document.getElementById('generate');
let opt = document.querySelector('#form');

generateButton.addEventListener("click",() => {
    if(opt.value == "chennai"){
        function generateTable(){
            console.log("Entered");
            const tbl = document.createElement("table");
            const tablBody = document.createElement("tbody");

    for(let i =0;i<r;i++){
        const row = tablBody.insertRow();
        const cell1 = row.insertCell();
        const cell2 = row.insertCell();
        cell1.textContent=" ";
        cell2.textContent=" ";
    }
    tbl.appendChild(tablBody);
    display.innerHTML.appendChild(tbl);
        }
    }
});*/

const generateButton = document.getElementById("generate");
const tableContainer = document.getElementById("second-output");

generateButton.addEventListener("click", () => {
  const numRows = 5; // Change this to change the number of rows in the table
  
  // Create the table element
  const tableElement = document.createElement("table");
  
  // Add the table headers
  const tableHeader = tableElement.createTHead();
  const headerRow = tableHeader.insertRow();
  const header1 = document.createElement("th");
  const header2 = document.createElement("th");
  const header3 = document.createElement("th");
  header1.textContent = "Header 1";
  header2.textContent = "Header 2";
  header3.textContent = "Header 3";
  headerRow.appendChild(header1);
  headerRow.appendChild(header2);
  headerRow.appendChild(header3);
  
  // Add the table body
  const tableBody = document.createElement("tbody");
  for (let i = 0; i < numRows; i++) {
    const row = tableBody.insertRow();
    const cell1 = row.insertCell();
    const cell2 = row.insertCell();
    const cell3 = row.insertCell();
    cell1.textContent = "Row " + (i+1) + ", Column 1";
    cell2.textContent = "Row " + (i+1) + ", Column 2";
    cell3.textContent = "Row " + (i+1) + ", Column 3";
  }
  
  // Add the table to the container element
  tableElement.appendChild(tableBody);
  tableContainer.appendChild(tableElement);
});