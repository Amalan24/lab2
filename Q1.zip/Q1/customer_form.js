let opt = document.querySelector('#form');
const generateButton = document.getElementById("generate");
const tableContainer = document.getElementById("display");

generateButton.addEventListener("click", () => {
  if(opt.value == "chennai"){
    generateTable(15);
  }
  else if(opt.value == "madurai"){
    generateTable(12);
  }
  else if(opt.value == "covai"){
    generateTable(12);
  }
  else if(opt.value == "salem"){
    generateTable(8);
  }
  else if(opt.value == "trichy"){
    generateTable(6);
  }
  else if(opt.value == "tuty"){
    generateTable(2);
  }
});

function generateTable(r){
  const numRows = r;
  const tableElement = document.createElement("table");
  const tableBody = document.createElement("tbody");
  const tableHeader = tableElement.createTHead();

  const headerRow = tableHeader.insertRow();
  const header1 = document.createElement("th");
  const header2 = document.createElement("th");
  const header3 = document.createElement("th");
  header1.textContent = "S.No";
  header2.textContent = "Product Name";
  header3.textContent = "Nos";
  headerRow.appendChild(header1);
  headerRow.appendChild(header2);
  headerRow.appendChild(header3);

  for (let i = 0; i < numRows; i++) {
    const row = tableBody.insertRow();
    const cell1 = row.insertCell();
    const cell2 = row.insertCell();
    const cell3 = row.insertCell();
  }
  
  tableContainer.innerHTML = "";
  tableElement.appendChild(tableBody);
  tableContainer.appendChild(tableElement);
}