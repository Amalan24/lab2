const output = document.getElementById('display');
const city = document.querySelector('#cities');
function submit(){
    if(city.value == "Chennai"){
        output.innerHTML = "Maximum of 15 items can be delivered to this location";
    }
    else if(city.value == "Coimbatore" || city.value == "Madurai"){
        output.innerHTML = "Maximum of 12 items can be delivered to this location";
    }
    else if(city.value == "Salem"){
        output.innerHTML = "Maximum 8 items can be delivered to this location";
    }
    else if(city.value == "Tiruchirappalli"){
        output.innerHTML = "Maximum 6 items can be delivered to this location";
    }
    else if(city.value == "Thoothukudi"){
        output.innerHTML = "Maximum 2 items can be delivered to this location";
    }
    else{
        output.innerHTML = "Select a location to deliver items";
    }
}

let lst=0;
let prod = document.getElementById('inputting');
let outputScreen = document.getElementById('list');
const itemList = [];
function save(){
    let a = prod.value;
    if(a!="" && city.value != ""){
        if(city.value == "Chennai")
          if(lst<15){
            itemList.push(a);
            console.log(itemList);
            outputScreen.value = itemList.join("\n");
            prod.value = "";
            ++lst;
        }
        else{
            alert("Delivery limit exceeds");        
        }    
    else if(city.value == "Coimbatore" || city.value == "Madurai"){
        if(lst<12){
            itemList.push(a);
            console.log(itemList);
            outputScreen.value = itemList.join("\n");
            prod.value = "";
        }
        else{
            alert("Delivery limit exceeds");        
        }
    }
    else if(city.value == "Salem"){
        if(lst<8){
            itemList.push(a);
            console.log(itemList);
            outputScreen.value = itemList.join("\n");
            prod.value = "";
        }
        else{
            alert("Delivery limit exceeds");
        }    
    }
    else if(city.value == "Tiruchirappalli"){
        if(lst<6){
            itemList.push(a);
            console.log(itemList);
            outputScreen.value = itemList.join("\n");
            prod.value = "";
        }    
        else{
            alert("Delivery limit exceeds");        
        }
    }
    else if(city.value == "Thoothukudi"){
        if(lst<2){
            console.log(lst);
            itemList.push(a);
            console.log(itemList);
            outputScreen.value = itemList.join("\n");
            prod.value = "";
            ++lst;
        }
        else{
            alert("Delivery limit exceeds");        
    }    
    }
    else{
        output.innerHTML = "Select a city to deliver items";
    }
    }
    console.log("Items : "+itemList); 
}
console.log(itemList); 
