const para = document.getElementById('demo');
para.innerHTML = "hello";
function preview(){
    for(let i = 0;i<itemList.length;i++){
        para.value = itemList[i].join("\n");
        console.log(itemList.length);
    }
}