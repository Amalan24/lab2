let outputScreen = document.getElementById('input-output');
let buttonClick = "False";
function un(){
    if(outputScreen.value == ""){
        outputScreen.value = "";
    }
    else{
        if(buttonClick=="False"){
        let word = "un"+outputScreen.value;
        outputScreen.value=word;
        }
        buttonClick = "True";
    }
}
function plus(){
    if(outputScreen.value == ""){
        outputScreen.value = "";
    }
    else{
        if(buttonClick=="False"){
            let word = "plus"+outputScreen.value;
            outputScreen.value=word;
        }
        buttonClick="True";
    }
}
function doubleplus(){
    if(outputScreen.value == ""){
        outputScreen.value = "";
    }
    else{
        if(buttonClick=="False"){
            let word = "doubleplus"+outputScreen.value;
            outputScreen.value=word;
        }
        buttonClick="True";
    }
}