const items = {
    1: {name: "Pencil", stock:10},
    2: {name: "Pen", stock:7},
    3: {name: "Inkbottle", stock:5},
    4: {name: "Eraser", stock:13},
    5: {name: "Sharpner", stock:15},
    6: {name: "Scale", stock:10},
    7: {name: "Fourline-note", stock:6},
    8: {name: "Twoline-note", stock:6},
    9: {name: "Ruled-note", stock:7},
    10: {name: "Unruled-note", stock:10}
};

let inputItems = document.querySelector('#itemsInput');
let inputNos = document.getElementById("nosInput");
let display = document.getElementById("output");

function getStock(){
    display.innerHTML = "";
    for(let i=0;i<10;i++){
        if(inputItems.value==""){
            display.innerHTML += items[i+1].name+" : "+items[i+1].stock +"<br>";
        }
        else if(inputItems.value==items[i+1].name && !(items[i+1].stock < 0)){
            if(items[i+1].stock > inputNos.value){
                items[i+1].stock -= inputNos.value;
                display.innerHTML = "Stock Remaining : "+items[i+1].stock;
            }
            else if(items[i+1].stock == inputNos.value){
                items[i+1].stock -= inputNos.value;
                display.innerHTML = "Out of Stock!!!<br>";
                display.innerHTML += "Stock Remaining : "+items[i+1].stock;

            }
            else if(items[i+1].stock < inputNos.value){
                display.innerHTML = "Out of Stock!!!<br>";
                display.innerHTML += "Stock Remaining : "+items[i+1].stock;
            }
            break;
        }
    } 
}
